import { PermissionsAndroid, Platform } from 'react-native'
import {
  mediaDevices,
  RTCPeerConnection,
  RTCSessionDescription,
  RTCIceCandidate,
} from 'react-native-webrtc'

// ─── InCallManager (speaker routing) ─────────────────────────────────────────
// Handles routing audio to loudspeaker vs earpiece during calls.
// Gracefully disabled if package is not installed.
let InCallManager = null
try {
  InCallManager = require('react-native-incall-manager').default
} catch (_) {
  console.warn('[WebRTC] react-native-incall-manager not found — speaker routing disabled')
}

// ─── STUN + TURN servers ─────────────────────────────────────────────────────
const ICE_SERVERS = [
  { urls: 'stun:stun.l.google.com:19302' },
  { urls: 'stun:stun1.l.google.com:19302' },
  { urls: 'stun:stun.relay.metered.ca:80' },
  {
    urls: 'turn:openrelay.metered.ca:80',
    username: 'openrelayproject',
    credential: 'openrelayproject',
  },
  {
    urls: 'turn:openrelay.metered.ca:443',
    username: 'openrelayproject',
    credential: 'openrelayproject',
  },
  {
    urls: 'turn:openrelay.metered.ca:443?transport=tcp',
    username: 'openrelayproject',
    credential: 'openrelayproject',
  },
]

const PC_CONFIG = {
  iceServers: ICE_SERVERS,
  iceCandidatePoolSize: 4,
  bundlePolicy: 'max-bundle',
  rtcpMuxPolicy: 'require',
  sdpSemantics: 'unified-plan',
}

let localStream  = null
let remoteStream = null
let peerConnection = null

// ICE buffer
let pendingCandidates = []
let remoteDescSet = false

// ─── Permissions ──────────────────────────────────────────────────────────────
export const requestCallPermissions = async (type = 'voice') => {
  if (Platform.OS !== 'android') return true
  try {
    const permissions = type === 'video'
      ? [PermissionsAndroid.PERMISSIONS.CAMERA, PermissionsAndroid.PERMISSIONS.RECORD_AUDIO]
      : [PermissionsAndroid.PERMISSIONS.RECORD_AUDIO]
    const granted = await PermissionsAndroid.requestMultiple(permissions)
    return Object.values(granted).every(
      (r) => r === PermissionsAndroid.RESULTS.GRANTED
    )
  } catch (err) {
    console.error('[WebRTC] Permission error:', err)
    return false
  }
}

// ─── Speaker routing ──────────────────────────────────────────────────────────
// forceSpeaker: true  → loudspeaker (video call default)
// forceSpeaker: false → earpiece   (voice call default)
export const setSpeaker = (forceSpeaker) => {
  if (!InCallManager || Platform.OS === 'web') return
  try {
    InCallManager.setSpeakerphoneOn(forceSpeaker)
    console.log(`[WebRTC] 🔊 Speaker ${forceSpeaker ? 'ON' : 'OFF'}`)
  } catch (err) {
    console.warn('[WebRTC] setSpeaker error:', err)
  }
}

// ─── Start InCallManager ──────────────────────────────────────────────────────
// Call this when entering the call screen.
// media: 'video' | 'audio'  — sets default routing automatically
export const startAudioSession = (media = 'audio') => {
  if (!InCallManager || Platform.OS === 'web') return
  try {
    InCallManager.start({ media })
    // Video call → loud speaker by default (Facebook/IMO style)
    if (media === 'video') {
      InCallManager.setSpeakerphoneOn(true)
    }
    console.log(`[WebRTC] 🎙️ Audio session started (${media})`)
  } catch (err) {
    console.warn('[WebRTC] startAudioSession error:', err)
  }
}

// ─── Stop InCallManager ───────────────────────────────────────────────────────
export const stopAudioSession = () => {
  if (!InCallManager || Platform.OS === 'web') return
  try {
    InCallManager.stop()
    console.log('[WebRTC] 🔇 Audio session stopped')
  } catch (err) {
    console.warn('[WebRTC] stopAudioSession error:', err)
  }
}

// ─── Local stream ─────────────────────────────────────────────────────────────
export const initLocalStream = async (isVideo = false) => {
  try {
    const constraints = {
      audio: {
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
        sampleRate: 48000,
        channelCount: 1,
      },
      video: isVideo ? {
        width:     { ideal: 640, max: 1280 },
        height:    { ideal: 480, max: 720 },
        frameRate: { ideal: 24, max: 30 },
        facingMode: 'user',
      } : false,
    }
    localStream = await mediaDevices.getUserMedia(constraints)
    console.log('[WebRTC] ✅ Local stream ready')
    return localStream
  } catch (err) {
    console.error('[WebRTC] Local stream error:', err)
    throw err
  }
}

// ─── Create peer connection ────────────────────────────────────────────────────
export const createPeerConnection = (callbacks = {}) => {
  const { onRemoteStream, onIceCandidate, onConnectionStateChange, onError } = callbacks

  try {
    pendingCandidates = []
    remoteDescSet = false

    peerConnection = new RTCPeerConnection(PC_CONFIG)

    if (localStream) {
      localStream.getTracks().forEach((track) => {
        peerConnection.addTrack(track, localStream)
      })
    }

    peerConnection.ontrack = (event) => {
      if (event.streams && event.streams[0]) {
        remoteStream = event.streams[0]
        onRemoteStream?.(remoteStream)
        console.log('[WebRTC] ✅ Remote stream received')
      }
    }

    peerConnection.onicecandidate = (event) => {
      if (event.candidate) onIceCandidate?.(event.candidate)
    }

    peerConnection.onconnectionstatechange = () => {
      const state = peerConnection?.connectionState
      console.log('[WebRTC] Connection state:', state)
      onConnectionStateChange?.(state)
      if (state === 'failed') {
        try { peerConnection.restartIce?.() } catch (_) {}
      }
    }

    peerConnection.oniceconnectionstatechange = () => {
      const state = peerConnection?.iceConnectionState
      console.log('[WebRTC] ICE state:', state)
      if (state === 'failed') {
        try { peerConnection.restartIce?.() } catch (_) {}
      }
    }

    console.log('[WebRTC] ✅ Peer connection created')
    return peerConnection
  } catch (err) {
    console.error('[WebRTC] Create peer connection error:', err)
    onError?.(err.message)
    throw err
  }
}

// ─── Offer / Answer ───────────────────────────────────────────────────────────
export const createOffer = async () => {
  if (!peerConnection) throw new Error('No peer connection')
  const offer = await peerConnection.createOffer({
    offerToReceiveAudio: true,
    offerToReceiveVideo: true,
  })
  await peerConnection.setLocalDescription(offer)
  console.log('[WebRTC] ✅ Offer created')
  return offer
}

export const createAnswer = async () => {
  if (!peerConnection) throw new Error('No peer connection')
  const answer = await peerConnection.createAnswer()
  await peerConnection.setLocalDescription(answer)
  console.log('[WebRTC] ✅ Answer created')
  return answer
}

// ─── Remote description + ICE flush ──────────────────────────────────────────
export const setRemoteDescription = async (description) => {
  if (!peerConnection) throw new Error('No peer connection')
  await peerConnection.setRemoteDescription(new RTCSessionDescription(description))
  remoteDescSet = true
  console.log('[WebRTC] ✅ Remote description set')

  if (pendingCandidates.length > 0) {
    console.log(`[WebRTC] Flushing ${pendingCandidates.length} buffered ICE candidates`)
    for (const c of pendingCandidates) {
      try { await peerConnection.addIceCandidate(new RTCIceCandidate(c)) }
      catch (err) { console.warn('[WebRTC] flush ICE err:', err.message) }
    }
    pendingCandidates = []
  }
}

// ─── ICE candidate ────────────────────────────────────────────────────────────
export const addIceCandidate = async (candidate) => {
  if (!candidate) return
  if (!peerConnection || !remoteDescSet) {
    pendingCandidates.push(candidate)
    return
  }
  try {
    await peerConnection.addIceCandidate(new RTCIceCandidate(candidate))
  } catch (err) {
    console.warn('[WebRTC] Add ICE candidate error:', err.message)
  }
}

// ─── Toggles ──────────────────────────────────────────────────────────────────
export const setMuted = (muted) => {
  if (localStream) localStream.getAudioTracks().forEach((t) => { t.enabled = !muted })
}

export const setVideoMuted = (muted) => {
  if (localStream) localStream.getVideoTracks().forEach((t) => { t.enabled = !muted })
}

export const switchCamera = () => {
  if (localStream) localStream.getVideoTracks().forEach((t) => t._switchCamera())
}

export const getLocalStream  = () => localStream
export const getRemoteStream = () => remoteStream
export const getPeerConnection = () => peerConnection
export const isRemoteDescSet = () => remoteDescSet

// ─── Cleanup ──────────────────────────────────────────────────────────────────
export const cleanup = () => {
  try {
    if (localStream) {
      localStream.getTracks().forEach((track) => track.stop())
      localStream = null
    }
    if (peerConnection) {
      try { peerConnection.close() } catch (_) {}
      peerConnection = null
    }
    remoteStream = null
    pendingCandidates = []
    remoteDescSet = false
    stopAudioSession()
    console.log('[WebRTC] ✅ Cleanup complete')
  } catch (err) {
    console.error('[WebRTC] Cleanup error:', err)
  }
}

// ─── Pre-warm ─────────────────────────────────────────────────────────────────
export const preWarmForCall = async (type = 'voice') => {
  try {
    const ok = await requestCallPermissions(type)
    if (ok) await initLocalStream(type === 'video')
  } catch (err) {
    console.error('[WebRTC] Pre-warm error:', err)
  }
}