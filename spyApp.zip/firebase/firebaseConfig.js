import { initializeApp, getApps, getApp } from 'firebase/app'

const firebaseConfig = {
  apiKey:            'AIzaSyBP1XKYCPzWmxS8DWCtW8nae6yDzbAAgEw',
  authDomain:        'kothaa.firebaseapp.com',
  projectId:         'kothaa',
  storageBucket:     'kothaa.firebasestorage.app',
  messagingSenderId: '921437174046',
  appId:             '1:921437174046:web:4a23eb872e77218b2fb10f',
}

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp()

let _auth = null

export const getFirebaseAuth = async () => {
  if (_auth) return _auth

  const isNative = typeof navigator !== 'undefined' && navigator.product === 'ReactNative'

  if (isNative) {
    // ✅ React Native (Android/iOS)
    const AsyncStorage = (await import('@react-native-async-storage/async-storage')).default
    const { initializeAuth, getReactNativePersistence } = await import('firebase/auth')
    _auth = initializeAuth(app, {
      persistence: getReactNativePersistence(AsyncStorage),
    })
  } else {
    // ✅ Web browser
    const { getAuth, browserLocalPersistence, initializeAuth } = await import('firebase/auth')
    try {
      _auth = initializeAuth(app, {
        persistence: browserLocalPersistence,
      })
    } catch {
      _auth = getAuth(app)
    }
  }

  return _auth
}

export const getAuth = () => _auth

export default app