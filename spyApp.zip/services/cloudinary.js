import * as ImageManipulator from 'expo-image-manipulator'

const CLOUD_NAME = 'dx6tr14vf'
const UPLOAD_PRESET = 'chat_app_upload'

// ─── Compress Image locally ───────────────────────────────────────────────────
const compressImage = async (uri) => {
  try {
    const result = await ImageManipulator.manipulateAsync(
      uri,
      [{ resize: { width: 1280 } }],
      {
        compress: 0.7,
        format: ImageManipulator.SaveFormat.JPEG,
      }
    )
    return result.uri
  } catch (_) {
    return uri
  }
}

// ─── Resource type for Cloudinary ────────────────────────────────────────────
const resourceFor = (type) => {
  if (type === 'image') return 'image'
  if (type === 'video') return 'video'
  if (type === 'audio' || type === 'voice') return 'video'
  return 'raw'
}

// ─── Main Upload Function ─────────────────────────────────────────────────────
export const uploadToCloudinary = async ({
  uri,
  type = 'image',
  name,
  mime,
  onProgress,
}) => {
  if (!uri) throw new Error('No file URI')

  let finalUri = uri

  if (type === 'image') {
    if (typeof onProgress === 'function') onProgress(0)
    finalUri = await compressImage(uri)
  }

  const resourceType = resourceFor(type)
  const endpoint = `https://api.cloudinary.com/v1_1/${CLOUD_NAME}/${resourceType}/upload`

  const form = new FormData()
  form.append('file', {
    uri: finalUri,
    name: name || `upload_${Date.now()}`,
    type: mime || 'application/octet-stream',
  })
  form.append('upload_preset', UPLOAD_PRESET)
  form.append('folder', `chat_app/${type}`)

  // ── Video: eager বাদ — Cloudinary async transformation এ upload hang করে ────
  // secure_url ই সরাসরি use করা হবে, Cloudinary delivery এ auto optimize করে
  if (type === 'video') {
    form.append('resource_type', 'video')
  }

  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest()
    xhr.open('POST', endpoint)

    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable && typeof onProgress === 'function') {
        const pct = Math.round((e.loaded / e.total) * 100)
        onProgress(pct)
      }
    }

    xhr.onload = () => {
      try {
        const data = JSON.parse(xhr.responseText)
        if (xhr.status >= 200 && xhr.status < 300 && data?.secure_url) {
          resolve({
            url: data.secure_url,          // সরাসরি secure_url — eager নেই
            public_id: data.public_id,
            resource_type: data.resource_type,
            width: data.width,
            height: data.height,
            duration: data.duration,       // video duration (seconds)
            bytes: data.bytes,
            format: data.format,
          })
        } else {
          reject(new Error(data?.error?.message || `Upload failed (${xhr.status})`))
        }
      } catch (err) {
        reject(err)
      }
    }

    xhr.onerror = () => reject(new Error('Network error during upload'))
    xhr.ontimeout = () => reject(new Error('Upload timed out'))
    xhr.timeout = 5 * 60 * 1000   // 5 মিনিট timeout — বড় video এর জন্য
    xhr.send(form)
  })
}

// ─── Format bytes helper ──────────────────────────────────────────────────────
export const formatBytes = (b) => {
  if (!b && b !== 0) return ''
  if (b < 1024) return `${b} B`
  if (b < 1024 * 1024) return `${(b / 1024).toFixed(1)} KB`
  return `${(b / (1024 * 1024)).toFixed(1)} MB`
}