
import { Platform, PermissionsAndroid } from 'react-native'

// react-native-agora — native module
let _createAgoraRtcEngine, _ChannelProfileType, _ClientRoleType,
    _RtcSurfaceView, _AudioScenario, _AudioProfile, _VideoMirrorModeType

try {
  const Agora = require('react-native-agora')
  _createAgoraRtcEngine  = Agora.createAgoraRtcEngine
  _ChannelProfileType    = Agora.ChannelProfileType
  _ClientRoleType        = Agora.ClientRoleType
  _RtcSurfaceView        = Agora.RtcSurfaceView
  _AudioScenario         = Agora.AudioScenario
  _AudioProfile          = Agora.AudioProfileType
  _VideoMirrorModeType   = Agora.VideoMirrorModeType
  console.log('[Agora] ✅ react-native-agora loaded')
} catch (_err) {
  console.warn('[Agora] ⚠️ Not linked — using mock. Run: npx expo run:android')
  const Mock = require('../mocks/agora-mock')
  _createAgoraRtcEngine = Mock.createAgoraRtcEngine
  _ChannelProfileType   = Mock.ChannelProfileType
  _ClientRoleType       = Mock.ClientRoleType
  _RtcSurfaceView       = null
  _AudioScenario        = null
}

export const RtcSurfaceView = _RtcSurfaceView
export const AGORA_APP_ID   = '6fbae39998f64fa3b34ab418d915c45f'

let engine          = null
let _eventHandlers  = {}

export const getEngine = () => engine

// ─────────────────────────────────────────────────────────────────────────────
// ✅ INSTANT CONNECT FIX:
// preWarmForCall → call:incoming এর সাথে সাথে call হয়।
// এটা permissions + engine init + audio pipeline একসাথে করে রাখে।
// User যখন accept press করবে ততক্ষণে 2-4 সেকেন্ড আগে থেকে সব ready।
// ─────────────────────────────────────────────────────────────────────────────
export const preWarmForCall = async (type = 'voice') => {
  try {
    await requestCallPermissions(type)
    const eng = initAgoraEngine()
    // Audio session early open — joinChannel এর first-frame latency কমায়
    try { eng?.enableLocalAudio?.(true) } catch (_) {}
    // ✅ NEW: Android audio route early set
    if (Platform.OS === 'android') {
      try { eng?.setEnableSpeakerphone(false) } catch (_) {}
    }
    console.log('[Agora] Pre-warm complete ✅')
  } catch (_) {}
}

// ─── Permissions ─────────────────────────────────────────────────────────────
export const requestCallPermissions = async (type = 'voice') => {
  if (Platform.OS !== 'android') return true

  const perms = [PermissionsAndroid.PERMISSIONS.RECORD_AUDIO]
  if (type === 'video') {
    perms.push(PermissionsAndroid.PERMISSIONS.CAMERA)
  }

  try {
    const res     = await PermissionsAndroid.requestMultiple(perms)
    const granted = perms.every(
      (p) => res[p] === PermissionsAndroid.RESULTS.GRANTED
    )
    if (!granted) console.warn('[Agora] Permissions denied:', res)
    return granted
  } catch (e) {
    console.warn('[Agora] Permission error:', e?.message)
    return false
  }
}

// ─── Engine init (singleton) ──────────────────────────────────────────────────
export const initAgoraEngine = () => {
  if (engine) return engine

  try {
    engine = _createAgoraRtcEngine()
    engine.initialize({
      appId: AGORA_APP_ID,
      // ✅ Communication mode — voice call এ onUserJoined সবচেয়ে দ্রুত fire করে
      channelProfile: _ChannelProfileType?.ChannelProfileCommunication ?? 0,
      audioScenario:  _AudioScenario?.AudioScenarioChatRoomEntertainment
                   ?? _AudioScenario?.AudioScenarioDefault
                   ?? 0,
    })

    engine.enableAudio()

    try {
      engine.setAudioProfile?.(
        _AudioProfile?.AudioProfileMusicStandard ?? 1,
        _AudioScenario?.AudioScenarioChatRoomEntertainment ?? 3
      )
      engine.enableDeepLearningDenoise?.(true)
      engine.setParameters?.(JSON.stringify({ 'che.audio.aec.mode': 2 }))
      engine.setParameters?.(JSON.stringify({ 'che.audio.enable.aec': true }))
      engine.setParameters?.(JSON.stringify({ 'che.audio.enable.ans': true }))
      engine.setParameters?.(JSON.stringify({ 'che.audio.enable.agc': true }))
      engine.setParameters?.(JSON.stringify({ 'che.audio.start.earpiece': true }))
      // ✅ NEW: low latency mode aggressively on
      engine.setParameters?.(JSON.stringify({ 'rtc.lowlatency': true }))
      engine.setParameters?.(JSON.stringify({ 'rtc.enable.video.cc': false }))

      if (Platform.OS === 'android') {
        engine.setParameters?.(
          JSON.stringify({ 'che.audio.androidCaptureBufferSizeInByte': 256 }) // 512→256: faster capture
        )
        engine.setParameters?.(
          JSON.stringify({ 'che.audio.keep.audiosession': true })
        )
        engine.setParameters?.(
          JSON.stringify({ 'che.audio.opensl': true })
        )
        // ✅ NEW: reduce audio render buffer for lower latency
        engine.setParameters?.(
          JSON.stringify({ 'che.audio.androidPlaybackBufferSizeInByte': 256 })
        )
      }

      if (Platform.OS === 'ios') {
        engine.setParameters?.(
          JSON.stringify({ 'che.audio.keep.audiosession': true })
        )
        // ✅ NEW: iOS audio buffer size reduction
        engine.setParameters?.(
          JSON.stringify({ 'che.audio.ios.category': 'AVAudioSessionCategoryPlayAndRecord' })
        )
      }
    } catch (_) {}

    console.log('[Agora] Engine initialized ✅')
  } catch (e) {
    console.warn('[Agora] initAgoraEngine failed:', e?.message)
    engine = null
  }

  return engine
}

// ─── Event Handler registration ───────────────────────────────────────────────
export const registerEventHandler = (handlers) => {
  _eventHandlers = { ..._eventHandlers, ...handlers }
  if (!engine) return
  try {
    engine.registerEventHandler({
      onJoinChannelSuccess: (conn) => {
        console.log('[Agora] ✅ onJoinChannelSuccess')
        _eventHandlers.onJoinChannelSuccess?.(conn)
      },

      onUserJoined: (conn, uid) => {
        console.log('[Agora] ✅ onUserJoined uid:', uid)
        _eventHandlers.onUserJoined?.(conn, uid)
      },

      onUserOffline: (conn, uid, reason) => {
        console.log('[Agora] onUserOffline uid:', uid, 'reason:', reason)
        _eventHandlers.onUserOffline?.(conn, uid)
      },

      onError: (errCode, msg) => {
        console.warn('[Agora] onError:', errCode, msg)
        _eventHandlers.onError?.(errCode)
      },

      onNetworkQuality: (conn, uid, txQuality, rxQuality) => {
        _eventHandlers.onNetworkQuality?.(conn, uid, txQuality, rxQuality)
      },

      onConnectionStateChanged: (conn, state, reason) => {
        console.log('[Agora] connectionState:', state, 'reason:', reason)
        _eventHandlers.onConnectionStateChanged?.(conn, state)
      },

      // ✅ Voice call এ onUserJoined দেরি করলে onRemoteAudioStateChanged দিয়ে trigger
      // state 2 = Decoding = remote audio আসছে = connected confirm
      onRemoteAudioStateChanged: (conn, uid, state) => {
        if (state === 2) {
          console.log('[Agora] ✅ Remote audio decoding — uid:', uid)
          _eventHandlers.onUserJoined?.(conn, uid)
        }
      },
    })
  } catch (e) {
    console.warn('[Agora] registerEventHandler failed:', e?.message)
  }
}

// ─── Destroy ──────────────────────────────────────────────────────────────────
export const destroyAgoraEngine = () => {
  if (!engine) return
  try {
    engine.unregisterEventHandler?.({})
    engine.release?.()
    console.log('[Agora] Engine released ✅')
  } catch (_) {}
  engine         = null
  _eventHandlers = {}
}

// ─── Join Channel ─────────────────────────────────────────────────────────────
export const joinChannel = async ({ token, channelName, uid, video = false }) => {
  const eng = initAgoraEngine()
  if (!eng) { console.warn('[Agora] joinChannel — no engine'); return }

  try {
    if (video) {
      eng.enableVideo()
      try {
        eng.setVideoEncoderConfiguration?.({
          dimensions:      { width: 640, height: 480 },
          frameRate:       15,
          bitrate:         0,
          minBitrate:      -1,
          orientationMode: 0,
          degradationPreference: 1,
          mirrorMode: _VideoMirrorModeType?.VideoMirrorModeAuto ?? 0,
        })
      } catch (_) {}
      try {
        eng.setBeautyEffectOptions?.(true, {
          lighteningContrastLevel: 1,
          lighteningLevel:         0.3,
          smoothnessLevel:         0.45,
          rednessLevel:            0.08,
        })
      } catch (_) {}
      try { eng.startPreview() } catch (_) {}
    } else {
      try { eng.disableVideo() } catch (_) {}
    }

    eng.setClientRole?.(_ClientRoleType?.ClientRoleBroadcaster ?? 1)
    try { eng.setEnableSpeakerphone(video) } catch (_) {}

    const numericUid = parseInt(uid, 10) || 0

    console.log('[Agora] Joining:', channelName, 'uid:', numericUid, 'video:', video)

    await eng.joinChannel(token, channelName, numericUid, {
      clientRoleType:         _ClientRoleType?.ClientRoleBroadcaster ?? 1,
      publishMicrophoneTrack: true,
      publishCameraTrack:     video,
      autoSubscribeAudio:     true,
      autoSubscribeVideo:     video,
      audienceLatencyLevel:   1,
    })

    console.log('[Agora] joinChannel sent ✅')
  } catch (e) {
    console.warn('[Agora] joinChannel failed:', e?.message)
  }
}

// ─── Leave ────────────────────────────────────────────────────────────────────
export const leaveChannel = async () => {
  if (!engine) return
  try {
    engine.stopPreview?.()
    await engine.leaveChannel()
    console.log('[Agora] leaveChannel ✅')
  } catch (_) {}
}

// ─── Controls ─────────────────────────────────────────────────────────────────
export const setMuted      = (m) => { try { engine?.muteLocalAudioStream(!!m)  } catch (_) {} }
export const setVideoMuted = (m) => { try { engine?.muteLocalVideoStream(!!m)  } catch (_) {} }
export const switchCamera  = ()  => { try { engine?.switchCamera()              } catch (_) {} }
export const setSpeaker    = (on)=> { try { engine?.setEnableSpeakerphone(!!on) } catch (_) {} }
