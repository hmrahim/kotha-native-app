import { Platform, PermissionsAndroid } from 'react-native'
import {
  createAgoraRtcEngine,
  ChannelProfileType,
  ClientRoleType,
  RtcSurfaceView,
} from 'react-native-agora'

export { RtcSurfaceView }

export const AGORA_APP_ID = '6fbae39998f64fa3b34ab418d915c45f'

let engine = null

export const getEngine = () => engine

export const requestCallPermissions = async (type = 'voice') => {
  if (Platform.OS !== 'android') return true
  const perms = [PermissionsAndroid.PERMISSIONS.RECORD_AUDIO]
  if (type === 'video') perms.push(PermissionsAndroid.PERMISSIONS.CAMERA)
  try {
    const result = await PermissionsAndroid.requestMultiple(perms)
    return perms.every((p) => result[p] === PermissionsAndroid.RESULTS.GRANTED)
  } catch (e) {
    console.log('perm err:', e?.message)
    return false
  }
}

export const initAgoraEngine = () => {
  if (engine) return engine
  engine = createAgoraRtcEngine()
  engine.initialize({
    appId: AGORA_APP_ID,
    channelProfile: ChannelProfileType.ChannelProfileCommunication,
  })
  engine.enableAudio()
  return engine
}

export const destroyAgoraEngine = () => {
  if (!engine) return
  try { engine.unregisterEventHandler({}); engine.release() } catch (_) {}
  engine = null
}

export const joinChannel = async ({ token, channelName, uid, video = false }) => {
  const eng = initAgoraEngine()
  if (video) { eng.enableVideo(); eng.startPreview() } else { eng.disableVideo() }
  eng.setClientRole(ClientRoleType.ClientRoleBroadcaster)
  eng.setEnableSpeakerphone(video)
  await eng.joinChannel(token, channelName, Number(uid), {
    clientRoleType: ClientRoleType.ClientRoleBroadcaster,
    channelProfile: ChannelProfileType.ChannelProfileCommunication,
    publishMicrophoneTrack: true,
    publishCameraTrack: video,
    autoSubscribeAudio: true,
    autoSubscribeVideo: video,
  })
}

export const leaveChannel = async () => {
  if (!engine) return
  try {
    engine.stopPreview()
    await engine.leaveChannel()
  } catch (_) {}
}

export const setMuted = (muted) => engine?.muteLocalAudioStream(!!muted)
export const setVideoMuted = (muted) => engine?.muteLocalVideoStream(!!muted)
export const switchCamera = () => engine?.switchCamera()
export const setSpeaker = (on) => engine?.setEnableSpeakerphone(!!on)