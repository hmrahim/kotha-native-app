
import React, { useEffect, useRef, useCallback } from 'react'
import {
  View, Text, StyleSheet, TouchableOpacity, Image,
  Animated, StatusBar, Platform, Dimensions,
} from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import { useRouter } from 'expo-router'
import { getSocket } from '../services/socket'
import { useCall } from '../context/CallContext'
import { stopRingtone } from '../services/sounds'
import {
  initAgoraEngine,
  requestCallPermissions,
  registerEventHandler,
  joinChannel,
  leaveChannel,
  destroyAgoraEngine,
  setSpeaker,
} from '../services/agora'

const { width: W, height: H } = Dimensions.get('window')

const C = {
  bg:      '#000000',
  green:   '#31A24C',
  red:     '#FA3E3E',
  white:   '#FFFFFF',
  whiteD:  'rgba(255,255,255,0.72)',
  whiteDD: 'rgba(255,255,255,0.40)',
  accent:  '#0084FF',
}

const safeStop = () => { try { stopRingtone() } catch (_) {} }

export default function IncomingCallScreen() {
  const router              = useRouter()
  const { state, dispatch } = useCall()
  const acceptingRef        = useRef(false)
  // ✅ INSTANT CONNECT: accept press হলেই joinChannel শুরু হবে।
  // Screen navigate হওয়ার আগেই Agora server connection চলবে।
  // তাই /call screen mount হওয়ার সময় remote peer ইতিমধ্যে joined বা join করছে।
  const earlyJoinDoneRef    = useRef(false)
  const earlyJoinParamsRef  = useRef(null) // { token, channelName, uid, type }

  // Animations
  const bgScale     = useRef(new Animated.Value(1.08)).current
  const avatarScale = useRef(new Animated.Value(0.85)).current
  const contentY    = useRef(new Animated.Value(30)).current
  const contentOp   = useRef(new Animated.Value(0)).current
  const btnScale    = useRef(new Animated.Value(0)).current
  const ripple1     = useRef(new Animated.Value(1)).current
  const ripple2     = useRef(new Animated.Value(1)).current
  const ripple1Op   = useRef(new Animated.Value(0.35)).current
  const ripple2Op   = useRef(new Animated.Value(0.2)).current

  // Entry animation
  useEffect(() => {
    Animated.parallel([
      Animated.timing(bgScale,    { toValue: 1, duration: 600, useNativeDriver: true }),
      Animated.timing(avatarScale,{ toValue: 1, duration: 500, useNativeDriver: true, delay: 100 }),
      Animated.timing(contentOp,  { toValue: 1, duration: 400, useNativeDriver: true, delay: 150 }),
      Animated.timing(contentY,   { toValue: 0, duration: 400, useNativeDriver: true, delay: 150 }),
      Animated.spring(btnScale,   { toValue: 1, useNativeDriver: true, tension: 90, friction: 7, delay: 300 }),
    ]).start()

    const rippleLoop = Animated.loop(
      Animated.sequence([
        Animated.parallel([
          Animated.timing(ripple1,   { toValue: 1.55, duration: 1200, useNativeDriver: true }),
          Animated.timing(ripple1Op, { toValue: 0,    duration: 1200, useNativeDriver: true }),
        ]),
        Animated.parallel([
          Animated.timing(ripple1,   { toValue: 1,    duration: 0, useNativeDriver: true }),
          Animated.timing(ripple1Op, { toValue: 0.35, duration: 0, useNativeDriver: true }),
        ]),
      ])
    )
    const rippleLoop2 = Animated.loop(
      Animated.sequence([
        Animated.delay(600),
        Animated.parallel([
          Animated.timing(ripple2,   { toValue: 1.55, duration: 1200, useNativeDriver: true }),
          Animated.timing(ripple2Op, { toValue: 0,    duration: 1200, useNativeDriver: true }),
        ]),
        Animated.parallel([
          Animated.timing(ripple2,   { toValue: 1,   duration: 0, useNativeDriver: true }),
          Animated.timing(ripple2Op, { toValue: 0.2, duration: 0, useNativeDriver: true }),
        ]),
      ])
    )
    rippleLoop.start()
    rippleLoop2.start()
    return () => { rippleLoop.stop(); rippleLoop2.stop() }
  }, [])

  // Auto-dismiss when call ends/canceled/rejected
  useEffect(() => {
    if (state.phase === 'idle' || state.phase === 'outgoing') {
      // ✅ যদি early join শুরু হয়ে গিয়ে থাকে কিন্তু user accept না করে,
      // তাহলে channel থেকে বের হতে হবে
      if (earlyJoinDoneRef.current) {
        leaveChannel().catch(() => {})
        destroyAgoraEngine()
        earlyJoinDoneRef.current = false
        earlyJoinParamsRef.current = null
      }
      safeStop()
      try { router.back() } catch (_) {}
    }
  }, [state.phase])

  if (!state.callId) return null
  const { callId, type, peer } = state
  const isVideo = type === 'video'

  const handleAccept = useCallback(() => {
    if (acceptingRef.current) return
    acceptingRef.current = true
    safeStop()

    const socket = getSocket()

    // ─────────────────────────────────────────────────────────────────────
    // ✅ INSTANT CONNECT — দুটো কাজ একসাথে parallel এ শুরু করো:
    //
    // [A] socket emit 'call:accept' → server থেকে token/uid/channel ack আসার অপেক্ষা
    // [B] Agora engine pre-warm (permissions + engine init হয় call:incoming এ)
    //
    // ack আসলে earlyJoin শুরু করো, তারপর navigate করো।
    // /call screen mount হওয়ার সময় engine ইতিমধ্যে joining/joined থাকবে।
    // ─────────────────────────────────────────────────────────────────────
    socket?.emit('call:accept', { callId }, async (ack) => {
      if (!ack?.ok) {
        acceptingRef.current = false
        dispatch({ type: 'RESET' })
        try { router.back() } catch (_) {}
        return
      }

      const callToken   = ack.token       || ''
      const callUid     = ack.uid         || ''
      const callChannel = ack.channelName || state.channelName || ''
      const callType    = ack.type        || type
      const callAppId   = ack.appId       || ''

      if (!callToken || !callUid || !callChannel) {
        console.warn('[IncomingCall] accept ack missing fields:', ack)
        acceptingRef.current = false
        dispatch({ type: 'RESET' })
        try { router.back() } catch (_) {}
        return
      }

      // ✅ CRITICAL SPEED FIX: ack পাওয়ার সাথে সাথেই joinChannel শুরু করো।
      // navigate() call করার আগেই Agora server connection establish হওয়া শুরু হবে।
      // /call screen mount হওয়ার আগেই channel join হয়ে যাবে (বা হতে থাকবে)।
      // /call screen এ setupDone guard এই early join detect করে skip করবে।
      try {
        const eng = initAgoraEngine()
        if (eng) {
          // Dummy event handler — /call screen mount হলে সে নিজের handler দিয়ে override করবে
          registerEventHandler({
            onJoinChannelSuccess: () => {
              console.log('[IncomingCall] ✅ Early channel join success!')
            },
            onUserJoined: (conn, uid) => {
              console.log('[IncomingCall] ✅ Remote user joined early! uid:', uid)
            },
          })

          await joinChannel({
            token:       String(callToken),
            channelName: String(callChannel),
            uid:         String(callUid),
            video:       callType === 'video',
          })

          earlyJoinDoneRef.current   = true
          earlyJoinParamsRef.current = {
            token: callToken,
            channelName: callChannel,
            uid: callUid,
            type: callType,
          }
          console.log('[IncomingCall] ✅ Early joinChannel done — navigating now')
        }
      } catch (joinErr) {
        console.warn('[IncomingCall] Early join failed (non-fatal):', joinErr?.message)
        // join fail হলেও navigate করো — /call screen নিজে join করবে
      }

      dispatch({ type: 'ACTIVE' })

      router.replace({
        pathname: '/call',
        params: {
          callId,
          channelName: callChannel,
          type:        callType,
          token:       String(callToken),
          uid:         String(callUid),
          appId:       String(callAppId),
          peerName:    peer?.name   || '',
          peerAvatar:  peer?.avatar || '',
          outgoing:    '0',
          // ✅ /call screen কে জানাও যে engine আগেই join করেছে
          earlyJoined: earlyJoinDoneRef.current ? '1' : '0',
        },
      })
    })
  }, [callId, type, state, peer, dispatch, router])

  const handleReject = useCallback(() => {
    safeStop()
    getSocket()?.emit('call:reject', { callId })
    dispatch({ type: 'RESET' })
    try { router.back() } catch (_) {}
  }, [callId, dispatch, router])

  return (
    <View style={s.root}>
      <StatusBar barStyle="light-content" backgroundColor="#000" translucent />

      {/* Blurred bg */}
      <Animated.View style={[StyleSheet.absoluteFill, { transform: [{ scale: bgScale }] }]}>
        {peer?.avatar ? (
          <Image
            source={{ uri: peer.avatar }}
            style={StyleSheet.absoluteFill}
            blurRadius={Platform.OS === 'ios' ? 50 : 25}
            resizeMode="cover"
          />
        ) : (
          <View style={[StyleSheet.absoluteFill, { backgroundColor: '#0d1117' }]} />
        )}
        <View style={[StyleSheet.absoluteFill, { backgroundColor: 'rgba(0,0,0,0.62)' }]} />
      </Animated.View>

      {/* Content */}
      <Animated.View style={[s.content, { opacity: contentOp, transform: [{ translateY: contentY }] }]}>
        <View style={s.pill}>
          <Ionicons name={isVideo ? 'videocam' : 'call'} size={13} color={C.white} />
          <Text style={s.pillTxt}>{isVideo ? 'Incoming Video Call' : 'Incoming Voice Call'}</Text>
        </View>

        <View style={s.avatarWrap}>
          <Animated.View style={[s.ripple, { transform: [{ scale: ripple1 }], opacity: ripple1Op }]} />
          <Animated.View style={[s.ripple, s.ripple2, { transform: [{ scale: ripple2 }], opacity: ripple2Op }]} />
          <Animated.View style={{ transform: [{ scale: avatarScale }] }}>
            {peer?.avatar ? (
              <Image source={{ uri: peer.avatar }} style={s.avatar} />
            ) : (
              <View style={[s.avatar, s.avatarFallback]}>
                <Text style={s.avatarLetter}>{(peer?.name?.[0] || '?').toUpperCase()}</Text>
              </View>
            )}
          </Animated.View>
        </View>

        <Text style={s.name}>{peer?.name || 'Unknown'}</Text>
        <Text style={s.subtitle}>{isVideo ? 'wants to video call you' : 'is calling you'}</Text>
      </Animated.View>

      {/* Action buttons */}
      <Animated.View style={[s.actions, { transform: [{ scale: btnScale }] }]}>
        <View style={s.btnItem}>
          <TouchableOpacity style={[s.actionBtn, s.declineBtn]} onPress={handleReject} activeOpacity={0.85}>
            <Ionicons name="call" size={30} color={C.white} style={{ transform: [{ rotate: '135deg' }] }} />
          </TouchableOpacity>
          <Text style={s.btnLbl}>Decline</Text>
        </View>

        <View style={s.btnItem}>
          <TouchableOpacity style={[s.actionBtn, s.acceptBtn]} onPress={handleAccept} activeOpacity={0.85}>
            <Ionicons name={isVideo ? 'videocam' : 'call'} size={30} color={C.white} />
          </TouchableOpacity>
          <Text style={s.btnLbl}>Accept</Text>
        </View>
      </Animated.View>
    </View>
  )
}

const AVATAR = 156
const RIPPLE = AVATAR * 0.95

const s = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#000',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: Platform.OS === 'android' ? 80 : 70,
    paddingBottom: Platform.OS === 'ios' ? 50 : 46,
  },
  content: {
    alignItems: 'center',
    flex: 1,
    justifyContent: 'center',
    gap: 0,
    marginBottom: 20,
  },
  pill: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: 'rgba(255,255,255,0.14)',
    paddingHorizontal: 14, paddingVertical: 6, borderRadius: 20,
    marginBottom: 40,
  },
  pillTxt: { color: C.white, fontSize: 12, fontWeight: '600', letterSpacing: 0.5 },
  avatarWrap: {
    width: AVATAR, height: AVATAR,
    alignItems: 'center', justifyContent: 'center',
    marginBottom: 28,
  },
  ripple: {
    position: 'absolute',
    width: RIPPLE, height: RIPPLE, borderRadius: RIPPLE / 2,
    backgroundColor: C.accent,
  },
  ripple2: {},
  avatar: {
    width: AVATAR, height: AVATAR, borderRadius: AVATAR / 2,
    borderWidth: 3, borderColor: 'rgba(255,255,255,0.28)',
    shadowColor: C.accent,
    shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0.45, shadowRadius: 24,
    elevation: 12,
  },
  avatarFallback: {
    backgroundColor: C.accent + '55',
    alignItems: 'center', justifyContent: 'center',
  },
  avatarLetter: { color: C.white, fontSize: 60, fontWeight: '700' },
  name: {
    color: C.white, fontSize: 30, fontWeight: '700', letterSpacing: 0.2,
    marginBottom: 8,
    textShadowColor: 'rgba(0,0,0,0.6)',
    textShadowOffset: { width: 0, height: 1 }, textShadowRadius: 8,
  },
  subtitle: { color: C.whiteDD, fontSize: 14, fontWeight: '400', letterSpacing: 0.5 },
  actions: { flexDirection: 'row', gap: 72, alignItems: 'center', paddingBottom: 10 },
  btnItem: { alignItems: 'center', gap: 10 },
  actionBtn: {
    width: 72, height: 72, borderRadius: 36,
    alignItems: 'center', justifyContent: 'center',
    shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.5, shadowRadius: 12,
    elevation: 10,
  },
  declineBtn: { backgroundColor: C.red,   shadowColor: C.red   },
  acceptBtn:  { backgroundColor: C.green, shadowColor: C.green },
  btnLbl: { color: C.whiteD, fontSize: 13, fontWeight: '600', letterSpacing: 0.3 },
})
